// Caféy bottom tab bar — mobile navigation chrome shared by the screen boards.
// Attributes: active="home|schedule|rhythm|care|base", dark (truthy) for the soft-dark ground.
class CafeyTabs extends HTMLElement {
  static get observedAttributes() { return ['active', 'dark']; }
  connectedCallback() { this.render(); }
  attributeChangedCallback() { if (this.isConnected) this.render(); }
  render() {
    const dark = this.hasAttribute('dark') && this.getAttribute('dark') !== 'false';
    const active = this.getAttribute('active') || 'home';
    const on = dark ? '#D9603F' : '#A33A21';
    const off = dark ? '#6B7278' : '#9AA0A6';
    const items = [
      ['home', 'Home', 'M4 11l8-6 8 6v8a1 1 0 0 1-1 1h-4v-6H9v6H5a1 1 0 0 1-1-1z'],
      ['schedule', 'Schedule', 'M4 8.5a2.5 2.5 0 0 1 2.5-2.5h11A2.5 2.5 0 0 1 20 8.5v9a2.5 2.5 0 0 1-2.5 2.5h-11A2.5 2.5 0 0 1 4 17.5zM8 3.5v4M16 3.5v4M4 11h16'],
      ['rhythm', 'Rhythm', 'M4 19.5h16M5 15l4-5 3.5 3L18 6'],
      ['care', 'Care', 'M12 3.5s5.8 6.3 5.8 10.2A5.8 5.8 0 0 1 6.2 13.7C6.2 9.8 12 3.5 12 3.5z'],
      ['base', 'Base', 'M7.5 9.5a2 2 0 0 1 2-2h5a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-5a2 2 0 0 1-2-2zM10 4.5v3M14 4.5v3M10 16.5v3M14 16.5v3M4.5 10h3M4.5 14h3M16.5 10h3M16.5 14h3']
    ];
    this.style.display = 'block';
    this.innerHTML = `<div style="display:grid;grid-template-columns:repeat(5,1fr);padding:12px 10px 28px;background:${dark ? '#1B1E21' : '#FFFFFF'};border-top:1px solid ${dark ? '#2A2E32' : '#EDE5DA'}">` +
      items.map(([key, label, d]) => {
        const c = key === active ? on : off;
        return `<div style="display:flex;flex-direction:column;align-items:center;gap:5px">
          <svg viewBox="0 0 24 24" fill="none" stroke="${c}" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" style="width:21px;height:21px"><path d="${d}"></path></svg>
          <span style="font:${key === active ? 600 : 500} 10.5px 'Instrument Sans',sans-serif;color:${c}">${label}</span>
        </div>`;
      }).join('') + '</div>';
  }
}
if (!customElements.get('cafey-tabs')) customElements.define('cafey-tabs', CafeyTabs);
