repo: Tavaressan/cafey
branch: main
path: (whole repo — firmware, backend spec and docs read as source material)

## Last sync

date: 2026-09-09T16:30:00Z

### Updated in this project

- Read README.md, STATUS.md and firmware/main/main.cpp to ground the UI in what the base can actually do.
- Manual control limited to start/stop with the firmware's `duracao_s` auto-off, since there is no water or temperature sensor.
- Schedules shown as stored on the base (NVS) and firing offline; Bluetooth presented as the fallback path.
- Device screen carries the real hardware: Britânia CP30 Inox 800 W / 127 V, panel button and RGB status LED on the pedestal.

## Screen map

| Screen (Cafey App.dc.html) | Built from |
|---|---|
| 1a Home dashboard | firmware/main/main.cpp (StartBrew / StopBrew, duracao_s), STATUS.md (LED pinout, relay) |
| 2a Schedule | firmware/main/main.cpp (ScheduleStore, Agendador, offline firing), README.md phase 3 |
| 2b Rhythm | README.md phase 3 (histórico de preparos, estatísticas) |
| 2c Care | README.md phase 3 (contador de descalcificação) |
| 2d Base | STATUS.md (coffee maker model, wattage, button, RGB LED), README.md (MQTT / AWS IoT, BLE fallback) |
